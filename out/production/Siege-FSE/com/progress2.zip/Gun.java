package com.company;

import javax.swing.*;
import java.awt.*;

public class Gun {
    public String name, type;
    public Image pic;
    public int use, ammo, recoil, damage, rof;
    public Gun(String [] stats){
        use = Integer.parseInt(stats[0]);
        name = stats[1];
        type = stats[2];
        damage = Integer.parseInt(stats[3]);
        ammo = Integer.parseInt(stats[4]);
        rof = Integer.parseInt(stats[5]);
        pic = new ImageIcon(stats[6]).getImage();
        recoil = 1;
    }
    //accessors
    public int getUse(){ return use; }
    public int getAmmo(){ return ammo; }
    public int getRecoil(){ return recoil; }
    public int getDam(){ return damage; }
    public int getRate(){ return rof; }

    public String getName(){ return name; }
    public String getType(){ return type; }
    public Image getPic(){ return pic; }
}
