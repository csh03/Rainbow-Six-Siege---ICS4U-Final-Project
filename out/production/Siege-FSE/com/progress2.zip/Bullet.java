package com.company;

public class Bullet {
}
