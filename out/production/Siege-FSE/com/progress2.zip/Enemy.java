package com.company;

public class Enemy {
}
