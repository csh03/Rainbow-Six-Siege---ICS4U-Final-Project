package com.company;

import java.awt.*;

public class Doorway {
    private Rectangle hitbox, actionBox;
    private boolean barricaded;
    private int health;

    public Doorway(Rectangle hitbox, Rectangle actionBox, boolean barricaded){
        this.barricaded = barricaded;
        this.hitbox=hitbox;
        this.actionBox = actionBox;
        health = 3;
    }
    public void barricade(){
        barricaded = true;
    }
    public void tearDown(){
        barricaded = false;
    }
    public Rectangle getHitbox() {
        return hitbox;
    }
    public Rectangle getActbox() { return actionBox; }
    public boolean isBarricaded() { return barricaded; }
    public void hit(){ health -= 1; }
}

