package com.company;

import java.awt.*;

public class HardWall {
    private Rectangle hitbox;

    public HardWall(Rectangle hitbox){
        this.hitbox=hitbox;
    }

    public Rectangle getHitbox() {
        return hitbox;
    }
}
