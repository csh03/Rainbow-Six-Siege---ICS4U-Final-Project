package com.company;

import java.awt.*;

public class SoftWall {
    private Rectangle hitbox;
    private boolean reinforced, intact;

    public SoftWall(Rectangle hitbox){
        reinforced = false;
        intact = true;
        this.hitbox=hitbox;
    }

    public void reinforce(){
        reinforced = true;
    }
    public void destroy(){
        intact = false;
    }
    public Rectangle getHitbox() {
        return hitbox;
    }
    public boolean isReinforced(){ return reinforced; }
    public boolean isIntact(){ return intact; }
}
