package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Rectangle;
import java.io.*;
import java.util.*;

public class GamePanel extends JPanel implements MouseListener, KeyListener { //GamePanel class - create new game object
    private boolean []keys;
    private Siege mainFrame;
    private Font gameFont;
    private Image bg1 = new ImageIcon("src/Assets/bg1.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private Image bg2 = new ImageIcon("src/Assets/bg2.png").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private Image bg3 = new ImageIcon("src/Assets/loadout.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private Image credBack = new ImageIcon("src/Assets/credits.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private Image playB = new ImageIcon("src/Assets/buttons/startB.png").getImage();
    private Image creditB = new ImageIcon("src/Assets/buttons/creditB.png").getImage();
    private Image quitB = new ImageIcon("src/Assets/buttons/quitB.png").getImage();
    private Image helpB = new ImageIcon("src/Assets/buttons/helpB.png").getImage();
    private Image prepB = new ImageIcon("src/Assets/buttons/prepB.png").getImage();
    private Image backB = new ImageIcon("src/Assets/buttons/exit.png").getImage();
    private Image startB = new ImageIcon("src/Assets/buttons/startGame.png").getImage();
    private Image map = new ImageIcon("src/Assets/map1.png").getImage();
    private Image currentBack;
    private ArrayList<HardWall> hardWalls = new ArrayList<>();
    private ArrayList<SoftWall> softWalls = new ArrayList<>();
    private ArrayList<Doorway> doors;
    public static final int LEFT=0, UP=1, RIGHT=2, DOWN=3;
    private Player player1;
    private String display;
    private Loadout l = new Loadout();
    private int offx, offy;

    //button rects
    private ArrayList <stateButton> active;
    private Rectangle backButton = new Rectangle(1100,30,143,47);

    public GamePanel(Siege m){
        keys = new boolean[KeyEvent.KEY_LAST+1];
        mainFrame = m;
        player1=new Player(490,310,75,3);
        setSize(814,600);
        addKeyListener(this);
        addMouseListener(this);
        doors = genDoors();
        try { //creating font
            gameFont = Font.createFont(Font.TRUETYPE_FONT, new File("src/Assets/fonts/Rainbow.ttf")); //downloading custom font
            gameFont = gameFont.deriveFont(18f); //size 18
        } catch (FontFormatException | IOException e) { //catches if no text file present, doesn't crash
            e.printStackTrace();
            System.exit(1);
        }
        player1 = new Player(606,300,150,2);
    }
    public void genWalls(String hWalls, String sWalls) throws IOException{
        Scanner inFile1 = new Scanner(new BufferedReader(new FileReader(hWalls)));
        Scanner inFile2 = new Scanner(new BufferedReader(new FileReader(sWalls)));
        while(inFile1.hasNext()){
            String line = inFile1.nextLine();
            String [] statList = line.split(" ");
            hardWalls.add(new HardWall(new Rectangle(Integer.parseInt(statList[0]) + offx, Integer.parseInt(statList[1]) + offy, Integer.parseInt(statList[2]), Integer.parseInt(statList[3]))));
        }
        while(inFile2.hasNext()){
            String line = inFile2.nextLine();
            String [] statList = line.split(" ");
            softWalls.add(new SoftWall(new Rectangle(Integer.parseInt(statList[0]) + offx, Integer.parseInt(statList[1]) + offy, Integer.parseInt(statList[2]), Integer.parseInt(statList[3]))));
        }
        inFile1.close();
        inFile2.close();
    }

    public ArrayList<Doorway> genDoors(){
        ArrayList<Doorway>doors = new ArrayList<Doorway>();
        doors.add(new Doorway(new Rectangle(521,575,29, 3), new Rectangle(521,565,29, 22),false));
        doors.add(new Doorway(new Rectangle(740,371,58, 3), new Rectangle(740,361,58, 22),true));
        doors.add(new Doorway(new Rectangle(698,626,3, 28), new Rectangle(688,626,22, 28),false));
        doors.add(new Doorway(new Rectangle(828,631,3, 28), new Rectangle(818,631,22, 28), false));
        doors.add(new Doorway(new Rectangle(1032,557,3, 45), new Rectangle(1022,557,22, 45), true));
        return doors;
    }

    public void loadStats(String fileName) throws IOException {
        Scanner inFile = new Scanner(new BufferedReader(new FileReader(fileName)));
        while(inFile.hasNext()){
            String line = inFile.nextLine();
            String [] statList = line.split(" ");
            Gun newGun = new Gun(statList);
            if(newGun.getUse() == 1){
                l.getpGuns().add(newGun);
            }
            else{
                l.getsGuns().add(newGun);
            }
        }
        inFile.close();
    }

    public void loadButtons(){
        active = new ArrayList<stateButton>();
        if(curr == State.MENU){
            active.add(new stateButton(new Rectangle(535, 190, 212, 96), State.SELECTION, playB));
            active.add(new stateButton(new Rectangle(535, 320, 212, 96), State.CREDITS, creditB));
            active.add(new stateButton(new Rectangle(535, 450, 212, 96), State.QUIT, quitB));
        }
        else if(curr == State.SELECTION){
            active.add(new stateButton(new Rectangle(535, 190, 212, 96), State.HELP, helpB));
            active.add(new stateButton(new Rectangle(535, 320, 212, 96), State.PREP, prepB));
        }
        else if(curr == State.PREP){
            active.add(new stateButton(new Rectangle(950, 600, 294, 53), State.GAME, startB));
        }
    }

    public void setBg(){
        if(curr == State.MENU) { currentBack = bg1; }
        else if(curr == State.CREDITS) { currentBack = credBack; }
        else if(curr == State.SELECTION) { currentBack = bg2; }
        else if(curr == State.PREP) { currentBack = bg3; }
        else if(curr == State.GAME) { currentBack = map; }
    }
    private enum State{
        MENU,
        PREP,
        GAME,
        CREDITS,
        SELECTION,
        HELP,
        QUIT
    }

    private GamePanel.State curr = GamePanel.State.GAME;

    public void checkQuit(){
        if(curr == State.QUIT){ System.exit(0); }
    }

    public void gamePlay(){
        repaint();
        setBg();
        loadButtons();
        checkQuit();
        if(curr == State.GAME){
            player1.setLoadout(l);
            move();
            getMapPos(player1.getX(),player1.getY());
        }
        if(curr != State.GAME){
            offx = 0;
            offy = 0;
        }
    }

    public static void delay (long len){ //delay - used to pause the game when death occurs
        try	{
            Thread.sleep (len);
        }
        catch (InterruptedException ex)	{
        }
    }

    public void move(){
        if(keys[KeyEvent.VK_D]) tryMove (player1, RIGHT);
        if(keys[KeyEvent.VK_A]) tryMove(player1, LEFT);
        if(keys[KeyEvent.VK_W]) tryMove(player1, UP);
        if(keys[KeyEvent.VK_S]) tryMove(player1, DOWN);
        /*
        if(keys[KeyEvent.VK_RIGHT]) tryMove (player2, RIGHT);
        if(keys[KeyEvent.VK_LEFT])  tryMove(player2, LEFT);
        if(keys[KeyEvent.VK_UP]) tryMove(player2, UP);
        if(keys[KeyEvent.VK_DOWN]) tryMove(player2, DOWN);*/
    }
    public void tryMove(Player player, int dir){
        player.walk(dir);
        for(HardWall wall:hardWalls){
            if(player.collide(wall.getHitbox())){
                player.walk((dir+2)%4);
                return;
            }
        }
        for(SoftWall wall:softWalls){
            if(wall.isIntact()){
                if(player.collide(wall.getHitbox())){
                    player.walk((dir+2)%4);
                    return;
                }
            }
        }
        for(Doorway door:doors){
            if(door.isBarricaded()){
                if(player.collide(door.getHitbox())){
                    player.walk((dir+2)%4);
                    return;
                }
            }
        }
    }
    public void setDefenses(){
        for(Doorway i : doors){
            if(player1.collide(i.getActbox()) && !player1.collide(i.getHitbox())){
                if(i.isBarricaded()) i.tearDown();
                else i.barricade();
            }
        }
    }

    public void getMapPos(int x, int y){
        if(720 - x > 0){ offx = 0; }
        else if(720 - x < -205){ offx = -205; }
        else{ offx = 720 - x; }

        if(360 - y > 0){ offy = 0; }
        else if(360 - y < -244){ offy = -244; }
        else{ offy = 360 - y; }
    }
    //methods needed to run window
    public void addNotify() {
        super.addNotify();
        requestFocus();
        mainFrame.start();
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        for(stateButton i : active){
            if(i.getRect().contains(e.getX(),e.getY())){
                curr = i.getState();
            }
        }
        if(backButton.contains(e.getX(),e.getY())){
            if(curr == State.SELECTION || curr == State.CREDITS){
                curr = State.MENU;
            }
            else if(curr == State.PREP || curr == State.HELP){
                l.cancel();
                curr = State.SELECTION;
            }
            else if(curr == State.GAME){
                curr = State.PREP;
            }
        }
    }
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {
        if(curr == State.PREP){
            for(Loadout.Button i : l.getPBs()){
                if(i.getRect().contains(e.getX(),e.getY())){
                    l.setPrimary(i.getGun());
                }
            }
            for(Loadout.Button i : l.getSBs()){
                if(i.getRect().contains(e.getX(),e.getY())){
                    l.setSecondary(i.getGun());
                }
            }
        }
    }
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    //gamePlay method - calls all the methods needed to run the game
    //getting keyboard input
    public void keyTyped(KeyEvent e) {
        if(curr == State.GAME){
            if(keys[KeyEvent.VK_E]){
                setDefenses();
            }
        }
    }

    public void keyPressed(KeyEvent e) { //pushed down
        keys[e.getKeyCode()] = true;
    }
    public void keyReleased(KeyEvent e) { //released
        keys[e.getKeyCode()] = false;
    }

    public void paint(Graphics g){//paint method - draws images needed for the game
        Point mouse = MouseInfo.getPointerInfo().getLocation();
        Point offset = getLocationOnScreen();
        System.out.println("("+(mouse.x-offset.x)+", "+(mouse.y-offset.y)+")");
        Graphics2D g2d = (Graphics2D) g;
        g2d.setStroke(new BasicStroke(3));
        g.drawImage(currentBack,offx,offy,null);
        if(curr != State.MENU) {
            g.drawImage(backB, 1100, 30, null);
            if (backButton.contains(mouse.x - offset.x, mouse.y - offset.y)) {
                g2d.draw(backButton);
            }
        }
        if(curr == State.GAME){
            g.setColor(Color.GREEN);
            g.fillOval(player1.getX()+offx,player1.getY()+offy,10,10);
            for(HardWall i : hardWalls){
                g2d.setColor(Color.GREEN);
                g2d.draw(new Rectangle((int)i.getHitbox().getX() + offx,(int)i.getHitbox().getY() + offy, (int)i.getHitbox().getWidth(), (int)i.getHitbox().getHeight()));
            }
            for(SoftWall i : softWalls){
                g2d.setColor(Color.BLUE);
                g2d.draw(new Rectangle((int)i.getHitbox().getX() + offx,(int)i.getHitbox().getY() + offy, (int)i.getHitbox().getWidth(), (int)i.getHitbox().getHeight()));
            }
            for(Doorway i : doors){
                g2d.setColor(Color.RED);
                if(i.isBarricaded()){
                    g2d.draw(new Rectangle((int)i.getHitbox().getX() + offx,(int)i.getHitbox().getY() + offy, (int)i.getHitbox().getWidth(), (int)i.getHitbox().getHeight()));
                }
            }
        }
        else if(curr == State.PREP){
            l.select(g);
            g.setColor(Color.WHITE);
            for(Loadout.Button i : l.getPBs()) {
                if (i.getRect().contains(mouse.x - offset.x, mouse.y - offset.y)) {
                    if(i.getGun() != l.getP()){
                        g2d.draw(i.getRect());
                    }
                }
            }
            for(Loadout.Button i : l.getSBs()) {
                if (i.getRect().contains(mouse.x - offset.x, mouse.y - offset.y)) {
                    if (i.getGun() != l.getS()) {
                        g2d.draw(i.getRect());
                    }
                }
            }
        }
        if(active != null) {
            for (stateButton i : active) {
                g.drawImage(i.getPic(), (int) i.getRect().getX(), (int) i.getRect().getY(), null);
                if (i.getRect().contains(mouse.x - offset.x, mouse.y - offset.y)) {
                    g2d.draw(i.getRect());
                } //drawing outline when mouse hovers over button
            }
        }
    }
    class stateButton{
        private Rectangle rect;
        private GamePanel.State state;
        private Image bPic;
        public stateButton(Rectangle rect, GamePanel.State state, Image bPic){
            this.rect = rect;
            this.state = state;
            this.bPic = bPic;
        }
        public Rectangle getRect(){ return rect; }
        public GamePanel.State getState(){ return state; }
        public Image getPic() { return bPic; }
    }
}
