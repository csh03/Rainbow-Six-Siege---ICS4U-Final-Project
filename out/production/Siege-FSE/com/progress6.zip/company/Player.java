package com.company;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.TimerTask;
import java.util.Timer;

public class Player{
    private int hp, score = 0, kills = 0;
    private final int maxhp;
    private final double normalv=Siege.spf*70, sprintv=Siege.spf*120;
    private double x, y, ang, v=normalv, fx, fy;
    private double switchprog=0;
    private final double switchSpeed=Siege.spf*2;
    private Shape hitbox;
    private Gun primary, secondary, equipped, gadget;
    private boolean acting=false, switching=false;
    private int reinforcements=3;
    private int spritePos = 0, spriteCount = 0;
    private final SoundEffect switchSound=new SoundEffect("Assets/sounds/shortSwitch.wav");
    private final BufferedImage [] moveSprites = new BufferedImage[8];
    private final BufferedImage [] actSprites = new BufferedImage[4];
    private BufferedImage currentSprite;
    private Timer aniTimer = new Timer();
    private boolean animating = false;
    private boolean moving = false;

    public Player(int x, int y, int maxhp) {
        this.x=x;
        this.y=y;
        updateHitbox();
        this.maxhp=maxhp;
        hp=maxhp;
        try {
            final BufferedImage moveSprite=ImageIO.read(new File("Assets/sprite.png"));
            for (int i = 0; i < 8; i++) {
                //moveSprites[i] = ImageIO.read(new File("Assets/sprites/walking/walk" + (i+1) + ".png"));
                moveSprites[i] = moveSprite.getSubimage(0, 35*i, 50, 35);
            }
            for (int i = 0; i < 4; i++) {
                actSprites[i] = ImageIO.read(new File("Assets/sprites/action/act" + (i + 1) + ".png"));
            }
        } catch(IOException ignored){}
    }

    public void face(double mx, double my){
        double dx=mx-x, dy=my-y;
        ang=Math.atan(dy/dx)+(dx<0?Math.PI:0);
        updateFront();
    }

    public void animate(int delay){
        if(moving) spriteCount = 7;
        else if(acting) spriteCount = 3;
        TimerTask aniTask = new TimerTask() {
            public void run() {
                if(spritePos < spriteCount){
                    spritePos++;
                }
                else{
                    if(moving) spritePos = 0;
                }
                if(moving) currentSprite = moveSprites[spritePos];
                else if(acting) currentSprite = actSprites[spritePos];
            }
        };
        if(!animating){
            aniTimer = new Timer();
            aniTimer.scheduleAtFixedRate(aniTask,0,delay);
        }
        animating = true;
    }
    public void stopAnimation(){
        if(animating) aniTimer.cancel();
        animating = false;
        spritePos = 0;
    }

    public void setLoadout(Loadout l){
        equipped=primary = l.getP();
        secondary = l.getS();
        gadget = l.getGadget();
    }

    public void switchGuns(){
        equipped.stopReload();
        if(!switching){
            switching=true;
            switchSound.play();
        }
        switchprog+=switchSpeed;
        if(switchprog >= 1){
            equipped=equipped==primary?secondary:primary;
            switchprog = 0;
            switching=false;
        }
    }

    public void stopSwitch(){
        switching=false;
    }
    public void stopMove(){ moving = false; }
    public void startMove(){ moving = true; }
    public double getSwitchProg(){ return switchprog; }

    public boolean isDead(){
        return hp<=0;
    }

    public void walk(double ang) {
        x+=v*Math.cos(ang);
        y-=v*Math.sin(ang);
        updateHitbox();
        updateFront();
    }
    public void addKill(){ kills++; }
    public void addScore(int tmp){ score += tmp; }

    //cjjtis
    public boolean checkLoadout(){
        return primary != null && secondary != null;
    }

    public void updateHitbox(){
        hitbox=new Ellipse2D.Double(x-10,y-10,23,23);
    }
    public void updateFront(){
        fx = x + 20*Math.cos(ang);
        fy = y + 20*Math.sin(ang);
    }

    public void hit(int damage){ hp-=damage;}
    public void heal(int health){ hp=Math.min(maxhp,hp+health); }

    public Point getPoint(){ return new Point((int)x,(int)y); }
    public double getAng(){ return ang; }

    public int getX(){ return (int) x-5; }
    public int getY(){ return (int) y-5; }
    public int getCenterX(){ return (int) x; }
    public int getCenterY(){ return (int) y; }
    public int getFrontX(){ return (int) fx; }
    public int getFrontY(){ return (int) fy; }
    public int getReinforcements(){ return reinforcements; }
    public int getHP(){ return hp; }
    public int getScore() { return score; }
    public int getKills() { return kills; }

    public Gun getP(){ return primary; }
    public Gun getS(){ return secondary; }
    public Gun getEquipped(){ return equipped; }
    public Gun getGadget(){ return gadget; }

    public BufferedImage getMoveSprite(){
        if(animating) return currentSprite;
        else return moveSprites[0]; //idle
    }
    public Shape getHitbox(){ return hitbox; }

    public boolean isSwitching(){ return switching; }
    public boolean isAnimating(){ return animating; }
    public boolean isMoving(){ return moving; }

    public boolean canReinforce(){ return reinforcements>0; }
    public boolean isSprinting(){
        return v==sprintv;
    }
    public void useReinforcement(){ reinforcements-=1; }
    public void sprint(){
        v = sprintv;
        equipped.stopReload();
    }
    public void normalSpeed(){
        v = normalv;
    }

    public boolean collide(Rectangle rect){
        return hitbox.intersects(rect);
    }

    public boolean checkHit(Bullet b){
        if (hitbox.contains(b.getPoint())){
            hit(b.getDmg());
            return true;
        }
        return false;
    }

    public void act(){
        acting=true;
        equipped.stopReload();
        switching=false;
    }
    public void stopAct(){
        acting=false;
    }
    public boolean isActing(){
        return acting;
    }
    public boolean canShoot(){
        return v==normalv&&!acting&&!equipped.isReloading()&&!switching;
    }
    public void shoot(){
        equipped.shoot();
        equipped.stopReload();
        switching=false;
    }
    public boolean canReload(){
        return v==normalv&&!acting&&!switching&&equipped.canReload();
    }
    public boolean canSwitch(){
        return !acting;
    }
}
