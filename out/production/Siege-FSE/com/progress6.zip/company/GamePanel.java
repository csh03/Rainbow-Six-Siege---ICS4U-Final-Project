package com.company;

import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import java.util.Timer;

public class GamePanel extends JPanel implements MouseListener, MouseMotionListener, KeyListener {
    private GamePanel.State state = GamePanel.State.PREP; //GamePanel class - create new game object
    public final int RIGHT=0, UP=1, LEFT=2, DOWN=3;

    private final boolean []keys;
    private final Siege mainFrame;
    private Font siegeFont, siegeFont2, niceFont;
    private final Image bg1 = new ImageIcon("Assets/bg1.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private final Image bg2 = new ImageIcon("Assets/bg2.png").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private final Image bg3 = new ImageIcon("Assets/loadout.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private final Image bg4 = new ImageIcon("Assets/pauseB.png").getImage();
    private final Image bg5 = new ImageIcon("Assets/errorB.png").getImage();
    private final Image bg6 = new ImageIcon("Assets/gameOver.png").getImage();
    private final Image bg7 = new ImageIcon("Assets/gameStats.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private final Image bg8 = new ImageIcon("Assets/gameOver2.png").getImage();
    private final Image credBack = new ImageIcon("Assets/credits.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private final Image playB = new ImageIcon("Assets/buttons/startB.png").getImage();
    private final Image creditB = new ImageIcon("Assets/buttons/creditB.png").getImage();
    private final Image quitB = new ImageIcon("Assets/buttons/quitB.png").getImage();
    private final Image helpB = new ImageIcon("Assets/buttons/helpB.png").getImage();
    private final Image prepB = new ImageIcon("Assets/buttons/prepB.png").getImage();
    private final Image backB = new ImageIcon("Assets/buttons/exit.png").getImage();
    private final Image startB = new ImageIcon("Assets/buttons/startGame.png").getImage();
    private final Image pauseB1 = new ImageIcon("Assets/buttons/pauseB1.png").getImage();
    private final Image pauseB2 = new ImageIcon("Assets/buttons/pauseB2.png").getImage();
    private final Image retryB = new ImageIcon("Assets/buttons/retry.png").getImage();
    private final Image gameStatsB = new ImageIcon("Assets/buttons/gameStats.png").getImage();
    private final Image backToMenu = new ImageIcon("Assets/buttons/backtomenu.png").getImage();
    private final Image map = new ImageIcon("Assets/map1.png").getImage();
    private final Image crosshair = new ImageIcon("Assets/crosshair.png").getImage().getScaledInstance(20,20,Image.SCALE_SMOOTH);
    private final Image infinity = new ImageIcon("Assets/infinity.png").getImage().getScaledInstance(70,35,Image.SCALE_SMOOTH);
    private final BufferedImage muzzle = ImageIO.read(new File("Assets/muzzle.png"));
    private Image currentBack;
    private Image secondaryBack;

    private final Music currentTheme = new Music();

    private final Rectangle[] boundaryRects=genBounds();

    private final Barrier[]hardwalls=genHardWalls("Assets/hardwalls.txt");
    private final Wall[]walls=genSoftWalls("Assets/softwalls.txt");
    private Door[] doors=genDoors();
    private ArrayList<Bullet> activeBullets=new ArrayList<>();
    private final ArrayList<Gun> enemyguns =new ArrayList<>();
    private ArrayList<Enemy>enemies = new ArrayList<>();
    private Player player1;
    private Hostage obj;
    private boolean canrev, prepPhase = true, musicPlaying = false, ticking = false, prepTicking = false;
    private Wall actablewall;
    private Door actabledoor;
    private final Loadout l = new Loadout();
    private double actionbar=0, actcooldown =0, buttonCooldown = 0;
    private final double coolspeed=Siege.spf/1;
    private double bulletcooldown=0, rof, reloadbar = 0, switchbar=0;
    private boolean click=false;
    private int prepSeconds;
    private int deathSeconds = 10;
    private int wave = 1;

    private final BufferedImage cursorHide = new BufferedImage(16,16,BufferedImage.TYPE_INT_ARGB);
    private final Cursor hidden;

    private Timer timer;
    private Timer deathTimer;

    //button rects
    private ArrayList <stateButton> active;
    private final Rectangle backButton = new Rectangle(1100,30,143,47);
    private int offx, offy, mx, my;

    private final SoundEffect firstRound = new SoundEffect("Assets/sounds/announcer1.wav");
    private final SoundEffect playerDead = new SoundEffect("Assets/sounds/announcer2.wav");
    private final SoundEffect fortifyRoom = new SoundEffect("Assets/sounds/announcer3.wav");
    private final SoundEffect enemyZone = new SoundEffect("Assets/sounds/announcer4.wav");
    private final SoundEffect hostageRevived = new SoundEffect("Assets/sounds/announcer5.wav");
    private final SoundEffect enemiesDead = new SoundEffect("Assets/sounds/announcer7.wav");
    private final SoundEffect newWave = new SoundEffect("Assets/sounds/announcer8.wav");
    private final SoundEffect hostageDead = new SoundEffect("Assets/sounds/announcer9.wav");
    private final SoundEffect hostageDown1 = new SoundEffect("Assets/sounds/announcer6.wav");
    private final SoundEffect hostageDown2 = new SoundEffect("Assets/sounds/announcer10.wav");
    ArrayList<Point>hasBeen=new ArrayList<>();


    public GamePanel(Siege m) throws IOException {
        keys = new boolean[KeyEvent.KEY_LAST+1];
        mainFrame = m;
        setSize(814,600);
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
        try { //creating font
            siegeFont = Font.createFont(Font.TRUETYPE_FONT, new File("Assets/fonts/Rainbow.ttf")).deriveFont(50f); //size 18
            siegeFont2 = Font.createFont(Font.TRUETYPE_FONT, new File("Assets/fonts/Rainbow.ttf")).deriveFont(30f);
            niceFont = Font.createFont(Font.TRUETYPE_FONT, new File("Assets/fonts/Roboto-Regular.ttf")).deriveFont(16f); //size 16
        } catch (FontFormatException | IOException e) { //catches if no text file present, doesn't crash
            e.printStackTrace();
        }
        player1 = new Player(606,300,100);
        obj = new Hostage(600,410,100);
        hidden = Toolkit.getDefaultToolkit().createCustomCursor(cursorHide,new Point(0,0),"hidden cursor");

        timer = new Timer();
    }

    public enum State{
        MENU, PREP, GAME, GAME_PAUSED, VICTORY, GAMEOVER_PLAYER, GAMEOVER_HOSTAGE, GAME_STATS, CREDITS, SELECTION, HELP, QUIT, ERROR;
    }

    public Wall[] genSoftWalls (String filename) throws IOException{
        Scanner inFile = new Scanner(new BufferedReader(new FileReader(filename)));
        int n=Integer.parseInt(inFile.nextLine());
        Wall[]walls=new Wall[n];
        for(int i=0;i<n;i++){
            String [] statList = inFile.nextLine().split(" ");
            walls[i]=new Wall(new Rectangle(Integer.parseInt(statList[0]), Integer.parseInt(statList[1]), Integer.parseInt(statList[2]), Integer.parseInt(statList[3])));
        }
        inFile.close();
        return walls;
    }

    public Barrier[] genHardWalls (String filename) throws IOException{
        Scanner inFile = new Scanner(new BufferedReader(new FileReader(filename)));
        int n=Integer.parseInt(inFile.nextLine());
        Barrier[]walls=new Barrier[n];
        for(int i=0;i<n;i++){
            String [] statList = inFile.nextLine().split(" ");
            walls[i]=new Barrier(new Rectangle(Integer.parseInt(statList[0]), Integer.parseInt(statList[1]), Integer.parseInt(statList[2]), Integer.parseInt(statList[3])));
        }
        inFile.close();
        return walls;
    }

    public Door[] genDoors(){
        Door[]doors=new Door[6];
        doors[0]= new Door (new Rectangle(520,575,31, 3),true);
        doors[1]= new Door (new Rectangle(739,371,61, 3),true);
        doors[2]= new Door (new Rectangle(698,625,3, 30),true);
        doors[3]= new Door (new Rectangle(827,630,3, 30), true);
        doors[4]= new Door (new Rectangle(1032,556,3, 47), true);
        doors[5]= new Door (new Rectangle(433,684,3, 48), true);
        return doors;
    }

    public Rectangle[]genBounds(){
        Rectangle[]bounds=new Rectangle[3];
        bounds[0]= new Rectangle(488,235,546,621);
        bounds[1]= new Rectangle(437,235,53,204);
        bounds[2]= new Rectangle(434,677,57,62);
        return bounds;
    }

    public void genEnemies(){
        if     (wave == 1) enemies.add(new Enemy(200,600,0, 100, enemyguns.get(randint(0, enemyguns.size()-1))));
        else if(wave == 2) enemies.add(new Enemy(200,600,0, 100, enemyguns.get(randint(0, enemyguns.size()-1))));
        else if(wave == 3) enemies.add(new Enemy(200,600,0, 100, enemyguns.get(randint(0, enemyguns.size()-1))));
        else if(wave == 4) enemies.add(new Enemy(200,600,0, 100, enemyguns.get(randint(0, enemyguns.size()-1))));
    }

    public void loadStats(String fileName) throws IOException {
        Scanner inFile = new Scanner(new BufferedReader(new FileReader(fileName)));
        String firstLine=inFile.nextLine();
        int n=Integer.parseInt(firstLine.substring(0,1));
        for(int i=0;i<n;i++){
            String line = inFile.nextLine();
            String [] statList = line.split(" ");
            Gun newGun = new Gun(statList);
            if(newGun.getUse() == 1){
                l.getpGuns().add(newGun);
                enemyguns.add(newGun);
            }
            else l.getsGuns().add(newGun);
        }
        inFile.close();
    }

    public void loadButtons(){
        active = new ArrayList<>();
        if(state == State.MENU){
            active.add(new stateButton(new Rectangle(535, 190, 212, 96), State.SELECTION, playB));
            active.add(new stateButton(new Rectangle(535, 320, 212, 96), State.CREDITS, creditB));
            active.add(new stateButton(new Rectangle(535, 450, 212, 96), State.QUIT, quitB));
        }
        else if(state == State.SELECTION){
            active.add(new stateButton(new Rectangle(535, 230, 212, 96), State.HELP, helpB));
            active.add(new stateButton(new Rectangle(535, 360, 212, 96), State.PREP, prepB));
        }
        else if(state == State.PREP) active.add(new stateButton(new Rectangle(950, 600, 294, 53), State.GAME, startB));
        else if(state == State.GAME_PAUSED){
            active.add(new stateButton(new Rectangle(475, 390, 110, 45), State.SELECTION, pauseB1));
            active.add(new stateButton(new Rectangle(675, 390, 110, 45), State.GAME, pauseB2));
        }
        else if(state == State.ERROR) active.add(new stateButton(new Rectangle(580, 340, 110, 45), State.PREP, pauseB2));
        else if(state == State.GAMEOVER_PLAYER || state == State.GAMEOVER_HOSTAGE){
            active.add(new stateButton(new Rectangle(465, 385, 110, 50), State.PREP, retryB));
            active.add(new stateButton(new Rectangle(660, 385, 167, 50), State.GAME_STATS, gameStatsB));
        }
        else if(state == State.GAME_STATS) active.add(new stateButton(new Rectangle(930, 610, 300, 53), State.SELECTION, backToMenu));
    }

    public void setBg(){
        if(state == State.MENU) currentBack = bg1;
        else if(state == State.CREDITS)  currentBack = credBack;
        else if(state == State.SELECTION) {
            currentBack = bg2;
            l.cancel();
        }
        else if(state == State.PREP) currentBack = bg3;
        else if(state == State.GAME) currentBack = map;
        else if(state == State.GAME_STATS) currentBack = bg7;
    }

    public void setSecondBg(){
        if(state == State.GAME_PAUSED) secondaryBack = bg4;
        else if(state == State.ERROR) secondaryBack = bg5;
        else if(state == State.GAMEOVER_HOSTAGE) secondaryBack = bg6;
        else if(state == State.GAMEOVER_PLAYER) secondaryBack = bg8;
    }

    public void checkQuit(){
        if(state == State.QUIT) System.exit(0);
    }

    public void reset() {
        for(Wall w : walls)w.reset();
        doors = genDoors();
        activeBullets = new ArrayList<>();
        prepSeconds = 0;
        prepPhase = true;
        prepTicking = false;
        player1 = new Player(606,300,100);
        obj = new Hostage(600,410,100);
        enemies = new ArrayList<>();
        genEnemies();
        l.cancel();
        wave = 1;
        for(Gun g : l.getpGuns()) g.resetAmmo();
        for(Gun g : l.getsGuns()) g.resetAmmo();
    }

    public void updateCursor(){
        if(state == State.GAME) mainFrame.setCursor(hidden);
        else mainFrame.setCursor(Cursor.getDefaultCursor());
    }

    public void playMusic(){
        if(state == State.GAME || state == State.GAME_PAUSED){
            currentTheme.stop();
            musicPlaying = false;
        }
        else{
            if(state == State.PREP) currentTheme.playSong("Assets/music/theme2.wav");
            else if(state == State.MENU || state == State.SELECTION || state == State.CREDITS || state == State.HELP) currentTheme.playSong("Assets/music/theme1.wav");
            else if(state == State.GAMEOVER_PLAYER || state == State.GAMEOVER_HOSTAGE) currentTheme.playSong("Assets/music/defeat.wav");
            if(!musicPlaying) musicPlaying = true;
        }
    }

    public void gameplay(){
        setBg();
        setSecondBg();
        loadButtons();
        checkQuit();
        player1.face(mx-offx,my-offy);
        getMapPos(player1.getX(),player1.getY());
        updateCursor();
        playMusic();

        if (buttonCooldown >0) buttonCooldown = Math.max(0, buttonCooldown - coolspeed);
        if(state == State.GAME) {
            move(player1);
            if(player1.isMoving()) player1.animate(100);
            else if(player1.isActing()) player1.animate(70);
            else{
                if(player1.isAnimating()) player1.stopAnimation();
            }
            //System.out.println((mx-offx)+", "+(my-offy));
            if(enemies.size() == 0){
                if(wave == 4){
                    enemiesDead.play();
                    state = State.VICTORY;
                }
                else{
                    wave++;
                    newWave.play();
                    genEnemies();
                    prepPhase = true;
                }
            }

            if (actcooldown >0) actcooldown = Math.max(0, actcooldown - coolspeed);
            updateActable();
            if (keys[KeyEvent.VK_E]) checkPosActions();
            else stopActions();

            rof = player1.getEquipped().getRate();
            if (bulletcooldown>0) bulletcooldown = Math.max(0,bulletcooldown-rof);

            playerShoot();

            for (Bullet b:activeBullets) {
                for (int i=0;i<b.getV();i++){
                    b.move();
                    if(bulletHit(b)) {
                        b.deactivate();
                        break;
                    }
                }
            }
            enemies.removeIf(Enemy::isDead);
            activeBullets.removeIf(b -> !b.isActive());

            Gun gun=player1.getEquipped();
            if (player1.canReload()&&(keys[KeyEvent.VK_R]||gun.isReloading())){
                gun.reload();
            }
            reloadbar=gun.getProg();

            if (player1.canSwitch()&&(keys[KeyEvent.VK_3]||player1.isSwitching())){
                player1.switchGuns();
            }
            switchbar=player1.getSwitchProg();

            checkEnemySight();
            if(!prepPhase){
                enemyShoot();
            }

            if(obj.isDead()) {
                hostageDown1.stop();
                hostageDown2.stop();
                hostageDead.play();
                state = State.GAMEOVER_HOSTAGE;
            }
            else if(player1.isDead()){
                playerDead.play();
                state = State.GAMEOVER_PLAYER;
            }
            if(!prepTicking && prepPhase){
                prepTicking = true;
                prepSeconds = 5;
                setGameTimer();
            }
            else if(prepSeconds == 0 && prepTicking){
                firstRound.play();
                timer.cancel();
                prepPhase = false;
                prepTicking = false;
            }

            if(player1.collide(boundaryRects[0])||player1.collide(boundaryRects[1])||player1.collide(boundaryRects[2])){
                if(deathTimer!=null) deathTimer.cancel();
                ticking = false;
                deathSeconds = 10;
            }
            else {
                if(!ticking){
                    deathCountdown();
                    ticking = true;
                }
                if(deathSeconds <= 0){
                    playerDead.play();
                    state = State.GAMEOVER_PLAYER;
                }
            }
        }
        if(state != State.GAME && state != State.GAME_PAUSED && state != State.GAMEOVER_HOSTAGE && state != State.GAMEOVER_PLAYER){
            offx = 0;
            offy = 0;
        }
        repaint();
    }

    public void playerShoot(){
        if (click) {
            if (player1.canShoot()) {
                if(player1.getEquipped().hasBullets()){
                    if(bulletcooldown==0) {
                        player1.shoot();
                        activeBullets.add(new Bullet(player1));
                        bulletcooldown = 1;
                        if (player1.getEquipped().isSemi()) click = false;
                    }
                }
                else player1.getEquipped().reload();
            }
        }
    }

    public void enemyShoot(){
        for(Enemy enemy: enemies){
            enemy.cooldown();
            if(enemy.hasEyes()){
                if(enemy.canShoot()){
                    if(enemy.getGun().hasBullets()){
                        activeBullets.add(new Bullet(enemy));
                        enemy.shoot();
                    }
                    else enemy.getGun().reload();
                }
            }
        }
    }

    public void checkEnemySight(){
        outerloop:
        for(Enemy enemy:enemies){
            Line2D line=new Line2D.Double(enemy.getPoint(),player1.getPoint());
            for(Barrier b:hardwalls){
                if(line.intersects(b.getHitbox())){
                    enemy.loseSight();
                    continue outerloop;
                }
            }
            for (Wall w:walls){
                if(line.intersects(w.getHitbox())&&(w.isIntact()||w.isReinforced())){
                    enemy.loseSight();
                    continue outerloop;
                }
            }
            for (Door d:doors){
                if(line.intersects(d.getHitbox())&&d.isBarricaded()){
                    enemy.loseSight();
                    continue outerloop;
                }
            }
            enemy.gainSight(player1.getPoint());
        }
    }

    public void deathCountdown(){
        enemyZone.play();
        deathTimer=new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
                if (deathSeconds >= 0) deathSeconds--;
            }
        };
        deathTimer.scheduleAtFixedRate(task, 1000, 1000);
    }

    public void setGameTimer() {
        if(wave == 1) fortifyRoom.play();
        timer = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
                if (prepSeconds >= 0) prepSeconds--;
            }
        };
        timer.scheduleAtFixedRate(task, 1000, 1000);
    }

    public void stopActions(){
        actionbar = 0;
        player1.stopAct();
        obj.stopRev();
        for (Door door : doors) door.stopAct();
        for (Wall wall : walls) wall.stopReinforce();
    }

    public void checkPosActions(){
        if (canrev) {
            player1.act();
            obj.revive();
            actionbar = obj.getProgress();
            if (actionbar == 0){
                actcooldown = 1;
                hostageRevived.play();
                player1.addScore(50);
            }
        } else if (actabledoor != null) {
            player1.act();
            actabledoor.act();
            actionbar = actabledoor.getProgress();
            if (actionbar == 0){
                actcooldown = 1;
                player1.addScore(5);
            }
        } else if (actablewall != null) {
            player1.act();
            actablewall.reinforce();
            actionbar = actablewall.getProgress();
            if (actionbar == 0) {
                player1.useReinforcement();
                actcooldown = 1;
                player1.addScore(10);
            }
        }
    }

    public boolean bulletHit (Bullet b){
        if (obj.checkHit(b)){
            if(obj.isDowned()){
                if(b.isFriendly()){
                    player1.addScore(-50);
                    hostageDown1.play();
                }
                else hostageDown2.play();
            }
            else if(obj.isDead()) {
                if(b.isFriendly()){
                    player1.addScore(-100);
                }
            }
            return true;
        }
        for (Enemy e:enemies){
            if(b.isFriendly()&&!prepPhase){
                if (e.checkHit(b)){
                    if(e.isDead()){
                        player1.addKill();
                        player1.addScore(100);
                    }
                    return true;
                }
            }
        }
        if (!b.isFriendly()) if (player1.checkHit(b)) return true;
        for (Barrier barrier: hardwalls) if (barrier.checkHit(b)) return true;
        for (Wall w: walls) if (w.checkHit(b)) return true;
        for (Door d:doors) if (d.checkHit(b)) return true;
        return false;
    }

    public void updateActable(){
        if (actcooldown==0) {
            canrev = obj.isDowned() && obj.inRange(player1);
            if (canrev) actabledoor = null;
            else {
                actabledoor = findActableDoor();
                if (actabledoor != null) actablewall = null;
                else actablewall = findActableWall();
            }
        }
        else{
            canrev=false;
            actabledoor=null;
            actablewall=null;
        }
    }

    public Door findActableDoor() {
        for(Door door : doors) if(door.inRange(player1)&&!player1.collide(door.getHitbox())) return door;
        return null;
    }

    public Wall findActableWall(){
        if(player1.canReinforce()) for(Wall w:walls) if(w.isActable()&&w.inRange(player1)&&!player1.collide(w.getHitbox())) return w;
        return null;
    }

    public static void delay (long len){ //delay - used to pause the game when death occurs
        try	{ Thread.sleep (len); }
        catch (InterruptedException ex){ }
    }
        /*
    public void checkEnemyPath(){
        for (Enemy e:enemies){
            if(!e.hasPath()){
                e.setPath(findPath(e));
            }
        }
    }

    public LinkedList<Integer> findPath(Enemy tmp){
        return findPath(tmp,new LinkedList<>());
    }

    public LinkedList<Integer> findPath(Enemy tmp, LinkedList<Integer>sofar){
        if(tmp.inRange(obj)) return sofar;

        LinkedList<Integer>rightpath=new LinkedList<>();
        LinkedList<Integer>uppath=new LinkedList<>();
        LinkedList<Integer>leftpath=new LinkedList<>();
        LinkedList<Integer>downpath=new LinkedList<>();

        for(Integer i:sofar){
            rightpath.addLast(i);
            uppath.addLast(i);
            leftpath.addLast(i);
            downpath.addLast(i);
        }

        Enemy rightguy=new Enemy(tmp.getCenterX(),tmp.getCenterY(),0,100,null);
        Enemy upguy=new Enemy(tmp.getCenterX(),tmp.getCenterY(),0,100,null);
        Enemy leftguy=new Enemy(tmp.getCenterX(),tmp.getCenterY(),0,100,null);
        Enemy downguy=new Enemy(tmp.getCenterX(),tmp.getCenterY(),0,100,null);

        int dist=50;

        if (canMove(rightguy,dist,RIGHT)){
            rightpath.add(0);
            rightpath=findPath(rightguy, rightpath);
        }
        else rightpath=null;

        if (canMove(upguy,dist,UP)){
            uppath.add(1);
            uppath=findPath(upguy, uppath);
        }
        else uppath=null;

        if (canMove(leftguy,dist,LEFT)){
            leftpath.add(2);
            leftpath=findPath(leftguy, leftpath);
        }
        else leftpath=null;

        if (canMove(downguy,dist,DOWN)){
            downpath.add(3);
            downpath=findPath(downguy, downpath);
        }
        else downpath=null;

        LinkedList<Integer>path = null;

        path=rightpath;
        if(uppath!=null){
            if(path==null) path=uppath;
            else if(uppath.size()<path.size()) path=uppath;
        }
        if(leftpath!=null){
            if(path==null) path=leftpath;
            else if(leftpath.size()<path.size()) path=leftpath;
        }
        if(downpath!=null){
            if(path==null) path=uppath;
            else if(downpath.size()<path.size()) path=downpath;
        }
        return path;
    }

    public boolean canMove (Enemy enemy, int dist, int dir){
        enemy.walk(dist,dir);
        if(enemy.isOut()) return false;
        for(Point p:hasBeen){
            if (enemy.getCenterX()==p.getX()&&enemy.getCenterY()==p.getY()){
                return false;
            }
        }
        hasBeen.add(new Point(enemy.getCenterX(),enemy.getCenterY()));
        if(enemy.collide(obj.getHitbox().getBounds())){
            enemy.walk(dist,(dir+2)%4);
            return false;
        }
        for(Barrier b : hardwalls){
            if(enemy.collide(b.getHitbox())){
                enemy.walk(dist,(dir+2)%4);
                return false;
            }
        }
        for(Wall wall: walls){
            if(wall.isIntact()){
                if(enemy.collide(wall.getHitbox())){
                    enemy.walk(dist,(dir+2)%4);
                    return false;
                }
            }
        }
        for(Door door:doors){
            if(door.isBarricaded()){
                if(enemy.collide(door.getHitbox())){
                    enemy.walk(dist,(dir+2)%4);
                    return false;
                }
            }
        }
        return true;
    }

    public void enemyMove(){
        for(Enemy e : enemies){
            e.move();
        }
    }
    */

    public void move (Player player){
        if (!player.isActing()) {
            if (keys[KeyEvent.VK_SHIFT]){
                player.sprint();
            }
            else{
                player.normalSpeed();
            }
            double ang=0;
            int count=0;
            if (keys[KeyEvent.VK_W]){
                ang+=Math.PI/2;
                count+=1;
            }
            if (keys[KeyEvent.VK_S]){
                ang+=3*Math.PI/2;
                count+=1;
            }
            if (keys[KeyEvent.VK_D]){
                count+=1;
                if (keys[KeyEvent.VK_S]) ang += 2*Math.PI;
            }
            if (keys[KeyEvent.VK_A]){
                ang+=Math.PI;
                count+=1;
            }
            if(count==1||count==2){
                player1.startMove();
                ang/=count;
                if(!tryMove(ang)) if(!tryMove(ang-Math.PI/4)) tryMove(ang+Math.PI/4);
            }
            else player1.stopMove();
        }
    }

    public boolean tryMove(double ang){
        player1.walk(ang);
        if(player1.collide(obj.getHitbox().getBounds())){
            player1.walk(ang+Math.PI);
            return false;
        }
        for(Barrier b : hardwalls){
            if(player1.collide(b.getHitbox())){
                player1.walk(ang+Math.PI);
                return false;
            }
        }
        for(Wall wall: walls){
            if(wall.isIntact()){
                if(player1.collide(wall.getHitbox())){
                    player1.walk(ang+Math.PI);
                    return false;
                }
            }
        }
        for(Door door:doors){
            if(door.isBarricaded()){
                if(player1.collide(door.getHitbox())){
                    player1.walk(ang+Math.PI);
                    return false;
                }
            }
        }
        if(prepPhase){
            if(!player1.collide(boundaryRects[0]) && !player1.collide(boundaryRects[1]) && !player1.collide(boundaryRects[2]) && !ticking){
                player1.walk(ang+Math.PI);
                return false;
            }
        }
        return true;
    }

    public void getMapPos (int x, int y){
        if(x<720) offx=0;
        else offx=Math.max(720-x, -205);
        if(y<360) offy=0;
        else offy=Math.max(360-y, -244);
    }

    //methods needed to run window
    public void addNotify() {
        super.addNotify();
        requestFocus();
        mainFrame.start();
    }

    public void mouseClicked(MouseEvent e) {
        for(stateButton i : active){
            if(i.getRect().contains(e.getX(),e.getY()) && buttonCooldown == 0){
                if(state == State.PREP){
                    player1.setLoadout(l);
                    if(player1.checkLoadout()){
                        rof=player1.getEquipped().getRate();
                        state = State.GAME;
                    }
                    else state = State.ERROR;
                }
                else state = i.getState();

                if(i.getState() == State.SELECTION || i.getState() == State.PREP){
                    reset();
                }
                buttonCooldown = 0.3;
            }
        }
        if(backButton.contains(e.getX(),e.getY()) && buttonCooldown == 0){
            if(state == State.SELECTION || state == State.CREDITS){
                state = State.MENU;
            }
            else if(state == State.PREP || state == State.HELP){
                l.cancel();
                state = State.SELECTION;
            }
            buttonCooldown = 0.3;
        }
    }

    public void mousePressed(MouseEvent e) {
        click=true;
    }

    public void mouseReleased(MouseEvent e) {
        click=false;
        if(state == State.PREP){
            for(Loadout.Button i : l.getPBs()){
                if(i.getRect().contains(e.getX(),e.getY())){
                    l.setPrimary(i.getGun());
                }
            }
            for(Loadout.Button i : l.getSBs()){
                if(i.getRect().contains(e.getX(),e.getY())){
                    l.setSecondary(i.getGun());
                }
            }
        }
    }
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    //gamePlay method - calls all the methods needed to run the game
    //getting keyboard input
    public void keyTyped(KeyEvent e) {
        if(state == State.GAME&&keys[KeyEvent.VK_ESCAPE]) state = State.GAME_PAUSED;
    }

    public void keyPressed(KeyEvent e) { //pushed down
        keys[e.getKeyCode()] = true;
    }
    public void keyReleased(KeyEvent e) { //released
        keys[e.getKeyCode()] = false;
    }
    public void mouseMoved(MouseEvent evt){
        mx = evt.getX();
        my = evt.getY();
    }
    public void mouseDragged(MouseEvent evt){
        mx = evt.getX();
        my = evt.getY();
    }

    public void paintComponent(Graphics g){//paint method - draws images needed for the game
        Graphics2D g2d = (Graphics2D) g;
        g2d.setStroke(new BasicStroke(3));
        if(state != State.GAME_PAUSED && state != State.ERROR && state != State.GAMEOVER_HOSTAGE && state != State.GAMEOVER_PLAYER) g.drawImage(currentBack,offx,offy,null);
        else{
            if(state == State.GAME_PAUSED) g.drawImage(secondaryBack, 450, 220, null);
            else if(state == State.GAMEOVER_HOSTAGE || state == State.GAMEOVER_PLAYER) g.drawImage(secondaryBack, 430, 220, null);
            else g.drawImage(secondaryBack, 450, 265,null);
        }

        if(state == State.SELECTION || state == State.HELP || state == State.PREP || state == State.CREDITS) {
            g.drawImage(backB, 1100, 30, null);
            if (backButton.contains(mx, my)) {
                g2d.draw(backButton);
            }
        }

        if(state == State.GAME) {
            g2d.setFont(niceFont);

            g2d.setColor(Color.RED);
            for(Bullet b:activeBullets) g2d.fillRect(b.getX()+offx,b.getY()+offy,3,3);
            //drawing sprite
            AffineTransform rot = new AffineTransform();
            rot.rotate(player1.getAng(),24,16);

            AffineTransformOp rotOp = new AffineTransformOp(rot, AffineTransformOp.TYPE_BILINEAR);
            g2d.drawImage(player1.getMoveSprite(), rotOp,(player1.getX()-19) + offx, (player1.getY()-11) + offy);
            //g2d.drawImage(muzzle, rotOp,(player1.getX()-10) + offx, (player1.getY()-10) + offy);

            if (obj.isDowned()) g2d.setColor(Color.RED);
            else g2d.setColor(Color.BLUE);
            g2d.fillOval(obj.getX() + offx, obj.getY() + offy, 10, 10);
            /*
            for (Barrier i : hardwalls) {
                g2d.setColor(Color.GREEN);
                Rectangle hitbox = i.getHitbox();
                g2d.drawRect((int) hitbox.getX() + offx, (int) hitbox.getY() + offy, (int) hitbox.getWidth(), (int) hitbox.getHeight());
            }
            g2d.setColor(Color.BLUE);*/

            for (Wall i : walls) {
                Rectangle hitbox = i.getHitbox();
                if (i.isReinforced()) {
                    g2d.drawRect((int) hitbox.getX() + offx, (int) hitbox.getY() + offy, (int) hitbox.getWidth(), (int) hitbox.getHeight());
                }
            }
            g2d.setColor(Color.RED);
            for (Door i : doors) {
                if (i.isBarricaded()) {
                    Rectangle hitbox = i.getHitbox();
                    g2d.drawRect((int) hitbox.getX() + offx, (int) hitbox.getY() + offy, (int) hitbox.getWidth(), (int) hitbox.getHeight());
                }
            }

            if (actcooldown == 0) {
                g2d.setColor(Color.WHITE);
                if (actionbar > 0) {
                    g2d.drawRect(610, 560, 60, 10);
                    g2d.fillRect(610, 560, (int) (60 * actionbar), 10);
                }
                if (canrev) g2d.drawString("Hold E to revive hostage", 550, 600);
                else if (actabledoor != null){
                    if (actabledoor.isBarricaded()) g2d.drawString("Hold E to remove barricade", 550, 600);
                    else g2d.drawString("Hold E to barricade", 575, 600);
                }
                else if (actablewall != null) g2d.drawString("Hold E to reinforce", 575, 600);
                g2d.setColor(Color.WHITE);
                g2d.drawString(Integer.toString(player1.getReinforcements()), 20, 655);
            }
            for(Enemy e : enemies){
                if(!prepPhase){
                    g2d.setColor(Color.yellow);
                    g2d.fillOval(e.getX() + offx,e.getY() + offy,10,10);
                    g2d.drawOval((int)(e.getMovebox().getX() + offx),(int) (e.getMovebox().getY() + offy),(int) e.getMovebox().getWidth(),(int) e.getMovebox().getHeight());
                }
            }
            g2d.setColor(Color.WHITE);
            if(reloadbar > 0){
                int x=player1.getCenterX()-30+offx;
                int y=player1.getY()-20+offy;
                g2d.drawRect(x, y, 60, 10);
                g2d.fillRect(x, y, (int) (60*reloadbar), 10);
            }
            g2d.setColor(Color.WHITE);
            if(switchbar>0) g2d.fillRect(970, 15, (int) (player1.getEquipped().getPic().getWidth(null) * switchbar), 5);
            g.drawImage(player1.getEquipped().getPic(), 970, 30, null);
            g2d.setFont(niceFont);
            g2d.drawString(player1.getEquipped().getMag()+"/"+player1.getEquipped().getAmmo(),40,300);
            g.drawImage(crosshair,mx-crosshair.getWidth(null)/2,my-crosshair.getHeight(null)/2,null);
            g2d.setFont(siegeFont);
            if(prepPhase){
                if(prepSeconds %60 >= 10) g2d.drawString(prepSeconds /60 + ":" + prepSeconds %60, 650 ,50);
                else g2d.drawString(prepSeconds /60 + ":0" + prepSeconds %60, 650 ,50);
            }
            else g.drawImage(infinity, 650,50,null);

            if(ticking){
                g2d.setFont(niceFont);
                g2d.drawString("Fall back! Enemy overwatch in the area.",600,400);
                if(deathSeconds%60 >= 10) g2d.drawString("You will die in: " + "0:" + deathSeconds%60, 650 ,420);
                else g2d.drawString( "You will die in: " + "0:0" + deathSeconds%60, 650 ,420);
            }
            g2d.setFont(niceFont);
            g2d.setColor(Color.WHITE);
            g2d.drawString("Wave " + wave, 250,50);
        }

        else if(state == State.PREP){
            l.select(g);
            g.setColor(Color.WHITE);
            for(Loadout.Button i : l.getPBs()) {
                if (i.getRect().contains(mx, my)) {
                    if(i.getGun() != l.getP()){
                        g2d.draw(i.getRect());
                    }
                }
            }
            for(Loadout.Button i : l.getSBs()) {
                if (i.getRect().contains(mx, my)) {
                    if (i.getGun() != l.getS()) {
                        g2d.draw(i.getRect());
                    }
                }
            }
        }

        else if(state == State.GAME_STATS){
            g2d.setFont(siegeFont);
            g2d.setColor(Color.WHITE);
            g2d.drawString("Kills: " + player1.getKills(), 450,200);
            g2d.drawString("Score: " + player1.getScore(), 450,270);
        }

        if(active != null) {
            for (stateButton i : active) {
                g.drawImage(i.getPic(), (int) i.getRect().getX(), (int) i.getRect().getY(), null);
                if (i.getRect().contains(mx, my)) {
                    g2d.draw(i.getRect());
                } //drawing outline when mouse hovers over button
            }
        }

        if(state == State.GAME || state == State.GAME_PAUSED){
            g2d.setFont(siegeFont2);
            g2d.setColor(Color.WHITE);
            g2d.drawString("Score: " + player1.getScore(), 40,40);
            g2d.drawString("Kills: " + player1.getKills(), 40,70);
            g2d.drawString("Health: " + player1.getHP(), 40,100);
        }
    }

    class Music{
        Clip c;
        String filename;
        public void setClip(String filename){
            this.filename = filename;
            try{
                File f = new File(filename);
                AudioInputStream sound = AudioSystem.getAudioInputStream(f);
                c = AudioSystem.getClip();
                c.open(sound);
            }catch(Exception e){ System.out.println("error"); }
        }
        public void play(){
            c.setFramePosition(0);
            c.start();
        }
        public void loop(){ c.loop(c.LOOP_CONTINUOUSLY); }
        public void stop(){
            c.stop();
            c.close();
        }
        public void playSong(String f){
            if (!f.equals(filename)) {
                if(c != null) stop();
                setClip(f);
                play();
                loop();
            }
        }
    }

    public static int randint (int low, int high){
        return (int) (Math.random()*(high-low+1)+low);
    }

    class stateButton{
        private Rectangle rect;
        private GamePanel.State state;
        private Image bPic;
        public stateButton(Rectangle rect, GamePanel.State state, Image bPic){
            this.rect = rect;
            this.state = state;
            this.bPic = bPic;
        }
        public Rectangle getRect(){ return rect; }
        public GamePanel.State getState(){ return state; }
        public Image getPic() { return bPic; }
    }
}