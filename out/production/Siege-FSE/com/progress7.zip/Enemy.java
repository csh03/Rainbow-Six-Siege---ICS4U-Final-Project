package com.company;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.LinkedList;

public class Enemy {
    public final int RIGHT=0, UP=1, LEFT=2, DOWN=3;
    private double ang, bulletcooldown=0;
    private int x,y,hp;
    private final int maxhp;
    private final double v = Siege.spf*70;
    private boolean dead=false, seesPlayer =false, justmoved=false, seesHostage;
    private final Gun gun;
    private Shape hitbox;
    private Ellipse2D movementCircle;
    private LinkedList<Integer>path=null;

    public Enemy (int x, int y, double ang, int maxhp, Gun gun){
        this.x = x;
        this.y = y;
        this.ang=ang;
        this.gun=gun;
        hp=this.maxhp=maxhp;
        updateHitbox();
        updateMovebox();
    }
    public void hit(int d){
        hp-=d;
        if(hp<=0) dead=true;
    }
    public int getX(){ return (int) x-5; }
    public int getY(){ return (int) y-5; }
    public int getCenterX(){ return (int) x; }
    public int getCenterY(){ return (int) y; }
    public Point getPoint(){ return new Point((int)x,(int)y);}
    public Gun getGun(){ return gun; }
    public double getAng(){ return ang; }
    public void updateHitbox(){
        hitbox=new Ellipse2D.Double(x-5,y-5,10,10);
    }
    public void updateMovebox(){ movementCircle=new Ellipse2D.Double(x-20,y-20,40,40); }
    public Shape getHitbox(){ return hitbox; }
    public Ellipse2D getMovebox(){ return movementCircle; }
    //public ArrayList<PathNode> getVisited(){ return visited; }
    public void gainEyes(Hostage obj){
        seesHostage =true;
        face(obj.getPoint());
    }
    public void gainEyes(Player player){
        seesPlayer =true;
        face(player.getPoint());
    }

    public void face(Point spot){
        double dx=spot.getX()-x, dy=spot.getY()-y;
        ang=Math.atan(dy/dx)+(dx<0?Math.PI:0);
    }
    public void loseEyes(Player p){ seesPlayer =false;}
    public void loseEyes(Hostage h){ seesHostage=false;}
    public boolean canShoot(){ return bulletcooldown==0;}
    public void shoot(){
        gun.shoot();
        bulletcooldown=1;
    }
    public void cooldown(){
        if (bulletcooldown>0) bulletcooldown = Math.max(0,bulletcooldown-gun.getRate());
    }

    public boolean checkHit(Bullet b){
        if (hitbox.contains(b.getPoint())){
            hit(b.getDmg());
            return true;
        }
        return false;
    }

    public void move(){
        if(path.size()>0&&!justmoved&&!seesPlayer&&!seesHostage) {
            int dir = path.removeFirst();
            if (dir == RIGHT) x += 1;
            if (dir == UP) y -= 1;
            if (dir == LEFT) x -= 1;
            if (dir == DOWN) y += 1;
            updateHitbox();
        }
        justmoved=!justmoved;
    }

    public boolean seesPlayer() {
        return seesPlayer;
    }
    public boolean seesHostage() {
        return seesHostage;
    }

    //public void addVisit(PathNode v){ visited.add(v); }

    public void setPath(LinkedList<Integer>path){
        this.path=path;
    }


    public boolean collide(Rectangle rect){
        return hitbox.intersects(rect);
    }

    public boolean inRange(Hostage obj){
        return Math.sqrt((obj.getX()-x)*(obj.getX()-x)+(obj.getY()-y)*(obj.getY()-y)) <100;
    }

    public boolean isOut(){ return x<0||x>1280||y<0||y>720; }

    public void setAng(double newAng){ ang = newAng; }
    public boolean isDead(){ return dead; }
}
