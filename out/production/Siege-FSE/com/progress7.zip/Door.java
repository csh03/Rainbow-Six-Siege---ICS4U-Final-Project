package com.company;

import java.awt.*;
import java.awt.geom.Ellipse2D;

public class Door {
    private Rectangle hitbox;
    private Ellipse2D actionbox;
    private boolean barricaded, finishsound;
    private int hp;
    private double progress=0;
    private final double bspeed=Siege.spf/2.5, tspeed=Siege.spf/0.6;
    private final SoundEffect bsound=new SoundEffect("Assets/Sounds/barricade.wav"), tsound=new SoundEffect("Assets/Sounds/teardown.wav");

    public Door (Rectangle hitbox, boolean barricaded){
        this.barricaded = barricaded;
        hp=barricaded?250:0;
        this.hitbox=hitbox;
        actionbox=new Ellipse2D.Double(hitbox.getCenterX()-14,hitbox.getCenterY()-14,28,28);
    }

    public void act(){
        finishsound=false;
        if(progress==0) {
            if (barricaded) tsound.play();
            else bsound.play();
        }
        progress += barricaded?tspeed:bspeed;
        if (progress>=1){
            barricaded=!barricaded;
            hp=barricaded?250:0;
            progress=0;
            finishsound=true;
        }
    }

    public void stopAct(){
        progress=0;
        if(!finishsound) {
            tsound.stop();
            bsound.stop();
        }
    }

    public void hit(int d){
        hp-=d;
        if(hp<=0) barricaded=false;
    }

    public boolean inRange(Player player){ return actionbox.contains(player.getFrontX(),player.getFrontY()); }
    public double getProgress(){ return progress; }
    public Rectangle getHitbox() { return hitbox; }
    public boolean checkHit(Bullet b){
        if(barricaded&&hitbox.contains(b.getPoint())){
            hit(b.getDmg());
            return true;
        }
        return false;
    }
    public boolean isBarricaded() { return barricaded; }
}

