package com.company;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;

public class Gun {
    private final String name, type;
    private final Image pic;
    private final int use, maxammo, damage, maxmag, v;
    private int mag, ammo;
    private double reloadProg=0;
    private final double dev, rof, longSpeed, shortSpeed;
    private boolean reloading=false;
    private final SoundEffect shortSound, longSound;
    private final LinkedList<SoundEffect> shotSounds=new LinkedList<>();
    private String[]stats;

    public Gun(String [] stats){
        this.stats=stats;
        use = Integer.parseInt(stats[0]);
        name = stats[1];
        type = stats[2];
        damage = Integer.parseInt(stats[3]);
        maxmag=Integer.parseInt(stats[4]);
        mag=maxmag+1;
        ammo=maxammo=maxmag*5;
        v=Integer.parseInt(stats[5]);
        rof = Double.parseDouble(stats[6])/(60*Siege.fps);
        dev = Double.parseDouble(stats[7]);
        pic = new ImageIcon(stats[8]).getImage();
        for(int i=0;i<50;i++){
            shotSounds.add(new SoundEffect("Assets/Sounds/"+name+"Shot.wav"));
        }
        shortSpeed=Siege.spf/Double.parseDouble(stats[9]);
        shortSound=new SoundEffect("Assets/Sounds/"+name+"ShortReload.wav");
        longSpeed=Siege.spf/Double.parseDouble(stats[10]);
        longSound=new SoundEffect("Assets/Sounds/"+name+"LongReload.wav");
    }

    public void resetAmmo(){
        mag=maxmag+1;
        ammo=maxammo;
    }

    public Gun clone(){
        return new Gun(stats);
    }

    public void resupply(){
        ammo = maxammo;
    }

    public void shoot(){
        shotSounds.getFirst().play();
        shotSounds.addLast(shotSounds.removeFirst());
        mag--;
    }

    public void reload(){
        if(ammo>0) {
            boolean empty = mag == 0;
            if (!reloading) {
                reloading = true;
                if (empty) longSound.play();
                else shortSound.play();
            }
            if (empty) reloadProg += longSpeed;
            else reloadProg += shortSpeed;
            if (reloadProg >= 1){
                int adding=Math.min(maxmag-mag+(empty?0:1), ammo);
                mag+=adding;
                ammo-=adding;
                reloadProg = 0;
                reloading = false;
            }
        }
    }

    public void stopReload(){
        longSound.stop();
        shortSound.stop();
        reloading=false;
        reloadProg=0;
    }

    //accessors
    public int getUse(){ return use; }
    public int getMaxAmmo(){ return maxammo; }
    public double getRecoil(){ return dev; }
    public int getDmg(){ return damage; }
    public int getMaxMag(){ return maxmag; }
    public int getMag(){ return mag; }
    public int getAmmo(){ return ammo; }
    public double getRate(){ return rof; }
    public double getDev(){ return dev; }
    public int getV(){ return v; }
    public double getProg(){ return reloadProg; }
    public boolean isReloading(){ return reloading; }
    public boolean canReload(){
        return mag<=maxmag;
    }
    public boolean isSemi(){ return type.equals("semi"); }
    public boolean hasBullets(){ return mag>0; }
    public String getName(){ return name; }
    public String getType(){ return type; }
    public Image getPic(){ return pic; }
}
