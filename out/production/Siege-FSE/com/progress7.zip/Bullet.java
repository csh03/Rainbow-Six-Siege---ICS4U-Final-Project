package com.company;

import java.awt.*;

public class Bullet{
    private double x,y;
    private final int dmg, v;
    private final double ang;
    private final boolean friendly;
    private boolean active;


    public Bullet(Player player){
        friendly=true;
        active=true;
        double offsetang=player.getAng()+Math.PI/2;
        x=player.getCenterX()+8*Math.cos(offsetang);
        y=player.getCenterY()+8*Math.sin(offsetang);
        Gun gun=player.getEquipped();
        dmg=gun.getDmg();
        v=gun.getV();
        double dev=gun.getDev();
        //double dx=mx-x, dy=my-y;
        ang=player.getAng()-0.05+randdouble(-dev,dev)*0.03;
        //Math.atan(dy/dx)+(dx<0?Math.PI:0)+randdouble(-dev,dev)*0.03;
    }

    public Bullet(Enemy enemy){
        friendly=false;
        active=true;
        x=enemy.getCenterX();
        y=enemy.getCenterY();
        Gun gun=enemy.getGun();
        dmg=gun.getDmg();
        v=gun.getV();
        double dev=gun.getDev();
        ang=enemy.getAng()+randdouble(-dev,dev)*0.15;
    }

    public void move(){
        x+=Math.cos(ang);
        y+=Math.sin(ang);
    }

    public int getX(){ return (int) x; }
    public int getY(){ return (int) y; }
    public int getV() { return v; }
    public Point getPoint(){ return new Point((int)x,(int)y); }
    public double getAng(){ return ang; }
    public void deactivate(){ active=false; }
    public boolean isActive(){ return active; }
    public int getDmg(){ return dmg; }
    public boolean isFriendly() { return friendly; }

    public double distTo(Player player){
        double dx=x-player.getCenterX(), dy=y-player.getCenterY();
        return Math.hypot(dx,dy);
    }

    public static double randdouble (double low, double high){
        return (Math.random()*(high-low)+low);
    }
}