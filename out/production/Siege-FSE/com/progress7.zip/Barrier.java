package com.company;

import java.awt.*;

public class Barrier {
    private final Rectangle hitbox;

    public Barrier(Rectangle hitbox){
        this.hitbox=hitbox;
    }

    public Rectangle getHitbox() {
        return hitbox;
    }

    public boolean checkHit(Bullet b){
        return hitbox.contains(b.getPoint());
    }
}
