package com.company;

class Spot {
    private Spot next;
    private int direction;
    private int x, y;
    private boolean visited;
    private final boolean blocked;

    public Spot(int x, int y, boolean blocked){
        this.blocked=blocked;
        if(!blocked) {
            this.x = x;
            this.y = y;
            visited = false;
        }
    }

    public boolean isAvailable(){ return !visited&&!blocked; }

    public void setDirection(int dir){
        direction=dir;
        visited=true;
    }

    public void setNext(Spot n){
        next=n;
    }
    public Spot getNext(){
        return next;
    }

    public int getDirection(){
        return direction;
    }

    public int getX(){ return x; }
    public int getY(){ return y; }
}