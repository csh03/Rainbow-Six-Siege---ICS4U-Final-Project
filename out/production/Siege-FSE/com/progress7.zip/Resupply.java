package com.company;

import java.awt.geom.Ellipse2D;

public class Resupply {
    private int x,y,supply;
    private final Ellipse2D actionbox;
    private final double resupplySpeed=Siege.spf/5;
    private double resupplyProgress = 0;

    public Resupply(int x,int y){
        this.x = x;
        this.y = y;
        supply = 5;
        actionbox=new Ellipse2D.Double(x-10,y-10,30,30);
    }

    public void startResupply(){
        resupplyProgress += resupplySpeed;
        if(resupplyProgress >= 1){
            resupplyProgress = 0;
            supply--;
        }
    }

    public void stopResupply(){
        resupplyProgress = 0;
    }

    public int getX(){ return x; }
    public int getY(){ return y; }
    public int getSupply(){ return supply; }
    public boolean hasSupply(){ return supply > 0; }
    public Ellipse2D getActionbox(){ return actionbox; }
    public double getProg(){ return resupplyProgress; }
}
