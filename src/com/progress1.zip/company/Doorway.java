package com.company;

public class Doorway {
}
