package com.company;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;
public class Siege extends JFrame implements ActionListener{
    Timer myTimer; //timer to call gameplay functions per frame
    GamePanel game;

    public Siege() throws IOException {
        super("R6 Siege"); //title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280,720);

        myTimer = new Timer(10, this);	 // trigger every 10 ms
        //creating new jPanel object
        game = new GamePanel(this);
        game.load("src/Assets/guns/stats.txt");
        add(game); //adding jPanel
        setResizable(false);
        setVisible(true);
    }

    public void start(){
        myTimer.start(); //starting timer
    }

    public void actionPerformed(ActionEvent evt){
        game.gamePlay();
    }

    public static void main(String[] arguments) throws IOException{
        Siege game = new Siege();
    }
}
