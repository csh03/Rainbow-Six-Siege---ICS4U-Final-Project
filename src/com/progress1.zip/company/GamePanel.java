package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class GamePanel extends JPanel implements MouseListener, KeyListener { //GamePanel class - create new game object
    private boolean []keys;
    private Siege mainFrame;
    private Font gameFont;
    private Image bg1 = new ImageIcon("src/Assets/bg1.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private Image bg2 = new ImageIcon("src/Assets/bg2.png").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private Image bg3 = new ImageIcon("src/Assets/loadout.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private Image credBack = new ImageIcon("src/Assets/credits.jpg").getImage().getScaledInstance(1280,720, Image.SCALE_SMOOTH);
    private Image playB = new ImageIcon("src/Assets/buttons/startB.png").getImage();
    private Image creditB = new ImageIcon("src/Assets/buttons/creditB.png").getImage();
    private Image quitB = new ImageIcon("src/Assets/buttons/quitB.png").getImage();
    private Image helpB = new ImageIcon("src/Assets/buttons/helpB.png").getImage();
    private Image prepB = new ImageIcon("src/Assets/buttons/prepB.png").getImage();
    private Image backB = new ImageIcon("src/Assets/buttons/exit.png").getImage();
    private Image startB = new ImageIcon("src/Assets/buttons/startGame.png").getImage();
    private Image map = new ImageIcon("src/Assets/map.jpg").getImage();
    private Image currentBack;
    private ArrayList<Wall> walls;

    private ArrayList <Gun> primary = new ArrayList<Gun>();
    private ArrayList <Gun> secondary = new ArrayList<Gun>();
    public static final int LEFT=0, UP=1, RIGHT=2, DOWN=3;
    private Player player;
    private String display;

    //button rects
    private ArrayList <stateButton> active;
    private Rectangle backButton = new Rectangle(1100,30,143,47);

    public GamePanel(Siege m){
        keys = new boolean[KeyEvent.KEY_LAST+1];
        mainFrame = m;
        player=new Player(490,310,100,2);
        walls = genWalls();
        setSize(814,600);
        addKeyListener(this);
        addMouseListener(this);
        try { //creating font
            gameFont = Font.createFont(Font.TRUETYPE_FONT, new File("src/Assets/fonts/Rainbow.ttf")); //downloading custom font
            gameFont = gameFont.deriveFont(18f); //size 18
        } catch (FontFormatException | IOException e) { //catches if no text file present, doesn't crash
            e.printStackTrace();
            System.exit(1);
        }
    }

    private ArrayList<Wall> genWalls(){
        ArrayList<Wall>walls=new ArrayList<Wall>();
        walls.add(new Wall(new Rectangle(875,497,11,211)));
        walls.add(new Wall(new Rectangle(875,423,11,32)));    // 455 ˅ door
        walls.add(new Wall(new Rectangle(875,187,11,151)));  // 337 ˅ soft
        walls.add(new Wall(new Rectangle(367,187,351,11))); // 718 > soft
        walls.add(new Wall(new Rectangle(779,187,112,11)));
        walls.add(new Wall(new Rectangle(367,187,11,180)));
        walls.add(new Wall(new Rectangle(367,355,56,11)));
        walls.add(new Wall(new Rectangle(411,355,11,206)));
        walls.add(new Wall(new Rectangle(366,551,56,11)));
        walls.add(new Wall(new Rectangle(366,551,11,60)));
        walls.add(new Wall(new Rectangle(366,600,56,11)));
        walls.add(new Wall(new Rectangle(411,600,11,109)));
        walls.add(new Wall(new Rectangle(411,697,476,11)));
        return walls;
    }

    public void loadButtons(){
        active = new ArrayList<stateButton>();
        if(curr == State.MENU){
            active.add(new stateButton(new Rectangle(535,190,212,96),State.SELECTION, playB));
            active.add(new stateButton(new Rectangle(535,320,212,96),State.CREDITS, creditB));
            active.add(new stateButton(new Rectangle(535,450,212,96),State.QUIT, quitB));
        }
        else if(curr == State.SELECTION){
            active.add(new stateButton(new Rectangle(535,190,212,96),State.HELP, helpB));
            active.add(new stateButton(new Rectangle(535,320,212,96),State.PREP, prepB));
        }
        else if(curr == State.PREP){
            active.add(new stateButton(new Rectangle(950,600,294,53),State.GAME, startB));
        }
    }

    public void setBg(){
        if(curr == State.MENU) { currentBack = bg1; }
        else if(curr == State.CREDITS) { currentBack = credBack; }
        else if(curr == State.SELECTION) { currentBack = bg2; }
        else if(curr == State.PREP) { currentBack = bg3; }
        else if(curr == State.GAME) { currentBack = map; }
    }

    public void load(String fileName) throws IOException{
        Scanner inFile = new Scanner(new BufferedReader(new FileReader(fileName)));
        while(inFile.hasNext()){
            String line = inFile.nextLine();
            String [] statList = line.split(" ");
            Gun newGun = new Gun(statList);
            if(newGun.getUse() == 1){
                primary.add(newGun);
            }
            else{
                secondary.add(newGun);
            }
        }
        inFile.close();
    }

    private enum State{
        MENU,
        PREP,
        GAME,
        CREDITS,
        SELECTION,
        HELP,
        QUIT;
    };
    private GamePanel.State curr = GamePanel.State.MENU;

    public void checkQuit(){
        if(curr == State.QUIT){ System.exit(0); }
    }

    public void gamePlay(){
        repaint();
        setBg();
        loadButtons();
        checkQuit();
        if(curr == State.GAME){
            move();
        }
    }

    public static void delay (long len){ //delay - used to pause the game when death occurs
        try	{
            Thread.sleep (len);
        }
        catch (InterruptedException ex)	{
            System.out.println("I hate when my sleep is interrupted");
        }
    }
    public void move(){
        if(keys[KeyEvent.VK_RIGHT]){
            tryMove(RIGHT);
        }
        if(keys[KeyEvent.VK_LEFT]){
            tryMove(LEFT);
        }
        if(keys[KeyEvent.VK_UP]){
            tryMove(UP);
        }
        if(keys[KeyEvent.VK_DOWN]){
            tryMove(DOWN);
        }
    }
    public void tryMove(int dir){
        player.walk(dir);
        for(Wall wall:walls){
            if(player.collide(wall.getHitbox())){
                player.walk((dir+2)%4);
                return;
            }
        }
    }
    /*
    public void loadSelect(Graphics g){
        addMouseListener(this);
        String display = "auto";
        ArrayList <Gun> displayed = new ArrayList<Gun>();
        Image label1 = new ImageIcon("src/Assets/label1.jpg").getImage();
        Image label2 = new ImageIcon("src/Assets/label2.jpg").getImage();
        Image label3 = new ImageIcon("src/Assets/label3.jpg").getImage();
        g.drawImage(label1, 420, 140,null);
        g.drawImage(label2, 515, 140,null);
        g.drawImage(label3, 715, 140,null);
        for(Gun i : primary){
            if(i.getType().equals(display)){
                displayed.add(i);
            }
        }
        for(int i = 0; i < displayed.size(); i++){
            g.drawImage(displayed.get(i).getPic(), 420, 200 + 110*i, null);
        }
        for(int i = 0; i < secondary.size(); i++){
            g.drawImage(secondary.get(i).getPic(), 680, 180 + 100*i, null);
        }
    }*/
    //methods needed to run window
    public void addNotify() {
        super.addNotify();
        requestFocus();
        mainFrame.start();
    }
    @Override
    public void mouseClicked(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {
        for(stateButton i : active){
            if(i.getRect().contains(e.getX(),e.getY())){
                curr = i.getState();
            }
        }
        if(backButton.contains(e.getX(),e.getY())){
            if(curr == State.SELECTION || curr == State.CREDITS){
                curr = State.MENU;
            }
            else if(curr == State.PREP || curr == State.HELP){
                curr = State.SELECTION;
            }
            else if(curr == State.GAME){
                curr = State.PREP;
            }
        }
    }
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    //gamePlay method - calls all the methods needed to run the game
    //getting keyboard input
    public void keyTyped(KeyEvent e) {}

    public void keyPressed(KeyEvent e) { //pushed down
        keys[e.getKeyCode()] = true;
    }
    public void keyReleased(KeyEvent e) { //released
        keys[e.getKeyCode()] = false;
    }

    public void paintComponent(Graphics g){//paintComponent method - draws images needed for the game
        Point mouse = MouseInfo.getPointerInfo().getLocation();
        Point offset = getLocationOnScreen();
        System.out.println("("+(mouse.x-offset.x)+", "+(mouse.y-offset.y)+")");
        Graphics2D g2d = (Graphics2D) g;
        g2d.setStroke(new BasicStroke(3));
        g.drawImage(currentBack,0,0,null);
        if(curr != State.MENU){
            g.drawImage(backB, 1100, 30,null);
            if(backButton.contains(mouse.x-offset.x,mouse.y-offset.y)){ g2d.draw(backButton); }
        }
        /*
        if(curr == State.PREP){
            loadSelect(g);
        }*/
        if(curr == State.GAME){
            g.setColor(Color.GREEN);
            g.fillOval(player.getX()-5,player.getY()-5,10,10);
        }
        if(active != null){
            for(stateButton i : active){
                g.drawImage(i.getPic(), (int) i.getRect().getX(), (int) i.getRect().getY(), null);
                if(i.getRect().contains(mouse.x-offset.x,mouse.y-offset.y)){ g2d.draw(i.getRect()); } //drawing outline when mouse hovers over button
            }
        }
    }

    class stateButton{
        private Rectangle rect;
        private GamePanel.State state;
        private Image bPic;
        public stateButton(Rectangle rect, GamePanel.State state, Image bPic){
            this.rect = rect;
            this.state = state;
            this.bPic = bPic;
        }
        public Rectangle getRect(){ return rect; }
        public GamePanel.State getState(){ return state; }
        public Image getPic() { return bPic; }
    }
}
