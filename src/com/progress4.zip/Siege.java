package com.company;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
public class Siege extends JFrame implements ActionListener{
    private final Timer myTimer; //timer to call gameplay functions per frame
    private final GamePanel game;
    public static final int fps=200;
    public static final double spf= (double) 1/fps;

    public Siege() throws IOException {
        super("R6 Siege"); //title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setPreferredSize(new Dimension(1280,720));
        pack();

        myTimer = new Timer(1000/fps, this);
        //creating new jPanel object
        game = new GamePanel(this);
        game.loadStats("Assets/guns/stats.txt");
        game.genEnemies();
        add(game); //adding jPanel
        //getContentPane().setCursor(Toolkit.getDefaultToolkit().createCustomCursor(null, new Point(0, 0), "blank cursor"));
        setResizable(false);
        setVisible(true);
    }

    public void start(){
        myTimer.start(); //starting timer
    }
    public void actionPerformed(ActionEvent evt){
        game.gameplay();
    }

    public static void main(String[] arguments) throws IOException {
        Siege game = new Siege();
    }

}
