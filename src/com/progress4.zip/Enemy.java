package com.company;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;

public class Enemy {
    private double x,y,hp, ang, bulletcooldown=0;
    private final int maxhp;
    private boolean dead=false, eyes=false, canShoot=true;
    private final Gun gun;
    private Shape hitbox;
    public Enemy (int x, int y, double ang, int maxhp, Gun gun){
        this.x = x;
        this.y = y;
        this.ang=ang;
        this.gun=gun;
        hp=this.maxhp=maxhp;
        updateHitbox();
    }
    public void hit(int d){
        hp-=d;
        if(hp<=0) dead=true;
    }
    public int getX(){ return (int) x-5; }
    public int getY(){ return (int) y-5; }
    public int getCenterX(){ return (int) x; }
    public int getCenterY(){ return (int) y; }
    public Point getPoint(){ return new Point((int)x,(int)y);}
    public Gun getGun(){ return gun; }
    public double getAng(){ return ang; }
    public void updateHitbox(){
        hitbox=new Ellipse2D.Double(x-5,y-5,10,10);
    }
    public Shape getHitbox(){ return hitbox; }
    public boolean hasEyes(){ return eyes;}
    public void gainSight(Point spot){
        eyes=true;
        double dx=spot.getX()-x, dy=spot.getY()-y;
        ang=Math.atan(dy/dx)+(dx<0?Math.PI:0);
    }
    public void loseSight(){ eyes=false;}
    public boolean canShoot(){ return bulletcooldown==0;}
    public void shoot(){
        gun.shoot();
        bulletcooldown=1;
    }
    public void cooldown(){
        if (bulletcooldown>0) bulletcooldown = Math.max(0,bulletcooldown-gun.getRate());
    }

    public boolean checkHit(Bullet b){
        if (hitbox.contains(b.getPoint())){
            hit(b.getDmg());
            return true;
        }
        return false;
    }
    public boolean isDead(){ return dead; }
}
