package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class Loadout{
    private Gun primary;
    private Gun secondary;
    private Gun gadget;

    ArrayList <Gun> pGuns = new ArrayList<>();
    ArrayList <Gun> sGuns = new ArrayList<>();
    ArrayList <Button> primaryBs = new ArrayList<>();
    ArrayList <Button> secondaryBs = new ArrayList<>();
    Image check = new ImageIcon("Assets/checkmark.png").getImage().getScaledInstance(25,25,Image.SCALE_SMOOTH);

    public void select(Graphics g){
        g.drawImage(new ImageIcon("Assets/label1.jpg").getImage(), 425, 140,null);
        g.drawImage(new ImageIcon("Assets/label2.jpg").getImage(), 715, 140,null);
        loadButtons();
        for(int i = 0; i < pGuns.size(); i++){
            g.drawImage(pGuns.get(i).getPic(), 420, 200 + 110*i, null);
            g.drawImage(sGuns.get(i).getPic(), 755, 190 + 100*i, null);
        }
        for(Button i : primaryBs){
            if(i.getGun() == primary){
                g.drawImage(check, (int) i.getRect().getX() + 210, (int) i.getRect().getY() + 60, null);
            }
        }
        for(Button i : secondaryBs){
            if(i.getGun() == secondary){
                g.drawImage(check, (int) i.getRect().getX() + 150, (int) i.getRect().getY() + 45, null);
            }
        }
    }

    public void loadButtons(){
        for(int i = 0; i < pGuns.size(); i++){
            primaryBs.add(new Button(new Rectangle(400, 190 + 112*i, 250, 100),pGuns.get(i)));
            secondaryBs.add(new Button(new Rectangle(715, 190 + 100*i, 190, 80),sGuns.get(i)));
        }
    }
    public Gun getP(){ return primary; }
    public Gun getS(){ return secondary; }
    public Gun getGadget(){ return gadget; }
    public ArrayList <Gun> getpGuns() { return pGuns; }
    public ArrayList <Gun> getsGuns() { return sGuns; }
    public ArrayList <Button> getPBs() { return primaryBs; }
    public ArrayList <Button> getSBs() { return secondaryBs; }

    public void setPrimary(Gun p){ primary = p; }
    public void setSecondary(Gun s){ secondary = s; }
    public void setGadget(Gun g){ gadget = g; }

    public void resetGuns(ArrayList<Gun>p, ArrayList<Gun>s) {
        pGuns = p;
        sGuns = s;
    }

    public void cancel(){
        primary = null;
        secondary = null;
        gadget = null;
    }

    class Button{
        private Rectangle rect;
        private Gun gun;
        public Button(Rectangle rect, Gun gun){
            this.rect = rect;
            this.gun = gun;
        }
        public Rectangle getRect(){ return rect; }
        public Gun getGun(){ return gun; }
    }
}
