package com.company;

import java.awt.*;
import java.awt.geom.Ellipse2D;

public class Wall {
    private final Rectangle hitbox;
    private final Ellipse2D actionbox;
    private boolean reinforced, intact, finishsound;
    private double progress;
    private final double rspeed=Siege.spf/4.5;
    private final SoundEffect rsound=new SoundEffect("Assets/Sounds/reinforce.wav");
    private int hp=1000;

    public Wall(Rectangle hitbox){
        reinforced = false;
        intact = true;
        this.hitbox=hitbox;
        actionbox=new Ellipse2D.Double(hitbox.getCenterX()-15,hitbox.getCenterY()-15,30,30);
    }

    public void reinforce(){
        finishsound=false;
        if(progress==0) rsound.play();
        progress+=rspeed;
        if(progress>=1){
            reinforced=true;
            progress=0;
            finishsound=true;
        }
    }

    public void hit(int d){
        hp-=d;
        if(hp<=0) intact=false;
    }

    public void reset(){
        reinforced = false;
        intact = true;
    }

    public void stopReinforce(){
        if(!finishsound) rsound.stop();
        progress = 0;
    }
    public Rectangle getHitbox() { return hitbox; }
    public double getProgress(){ return progress; }
    public boolean isIntact(){ return intact; }
    public boolean isActable(){ return !reinforced; }
    public boolean isReinforced(){ return reinforced; }
    public boolean checkHit(Bullet b){
        if ((intact||reinforced)&&hitbox.contains(b.getPoint())){
            if (intact&&!reinforced) hit(b.getDmg());
            return true;
        }
        return false;
    }
    public boolean inRange(Player player){
        return actionbox.contains(player.getCenterX(),player.getCenterY());
    }
}
