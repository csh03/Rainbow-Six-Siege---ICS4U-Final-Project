package com.company;

import java.awt.*;
import java.awt.geom.Ellipse2D;

public class Hostage {
    private final int x,y, maxhp, downedhp=40;
    private int hp;
    private boolean downed = false;
    private final double revspeed=Siege.spf/2;
    private double revprogress = 0;
    private final Shape hitbox;
    private final Ellipse2D actionbox;
    public Hostage(int x, int y, int hp){
        this.x = x;
        this.y = y;
        this.hp = hp;
        maxhp = 100;
        hitbox=new Ellipse2D.Double(x-5,y-5,10,10);
        actionbox=new Ellipse2D.Double(x-15,y-15,30,30);
    }
    public void revive(){
        revprogress += revspeed;
        if (revprogress>=1){
            downed = false;
            hp=maxhp;
            revprogress = 0;
        }
    }

    public void stopRev(){
        revprogress=0;
    }

    private void hit(int d){
        hp-=d;
    }

    public boolean isDead(){
        return hp<=0;
    }

    public void checkDown(){
        if(hp<=0){
            if (!downed){
                hp=downedhp;
                downed=true;
            }
            else downed = false;
        }
    }

    public boolean checkHit(Bullet b){
        if (hitbox.contains(b.getPoint())){
            hit(b.getDmg());
            checkDown();
            return true;
        }
        return false;
    }

    public boolean inRange(Player player){
        return actionbox.contains(player.getCenterX(),player.getCenterY());
    }
    public double getProgress(){ return revprogress; }
    public boolean isDowned(){ return downed; }
    public Shape getHitbox(){ return hitbox; }

    public Shape getActbox(){ return actionbox; }
    public int getX(){ return x-5; }
    public int getY(){ return y-5; }
}
